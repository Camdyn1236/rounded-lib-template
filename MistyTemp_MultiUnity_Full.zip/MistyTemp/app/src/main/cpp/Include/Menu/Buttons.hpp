#pragma once
#include <BNMResolve.hpp>
#include <functional>
#include <string>
#include "ButtonInfo.hpp"
#include "Settings.hpp"
#include "../NotiLib/NotiLib.hpp"
#include "../ModInclude.hpp"

using namespace BNM;
using namespace BNM::IL2CPP;
using namespace BNM::Structures;

class Buttons {
public:
    static inline std::vector<std::vector<ButtonInfo>> buttons = {
            {//main stuff - 0
                    ButtonInfo {.buttonText = "Settings", .method = []() { Settings::setCurrentCategory(1); }, .isTogglable = false, .toolTip = "Opens the settings"},
                    ButtonInfo {.buttonText = "Movement", .method = []() { Settings::setCurrentCategory(2); }, .isTogglable = false, .toolTip = "Opens movement"},
                    ButtonInfo {.buttonText = "Player", .method = []() { Settings::setCurrentCategory(3); }, .isTogglable = false, .toolTip = "Opens player"},
                    ButtonInfo {.buttonText = "Overpowered", .method = []() { Settings::setCurrentCategory(4); }, .isTogglable = false, .toolTip = "Opens overpowered"},
                    ButtonInfo {.buttonText = "Bots", .method = []() { Settings::setCurrentCategory(7); }, .isTogglable = false, .toolTip = "Photon bots controller"},
                    ButtonInfo {.buttonText = "Credits", .method = []() { Settings::setCurrentCategory(5); }, .isTogglable = false, .toolTip = "Opens the cedits"},
                    ButtonInfo {.buttonText = "Cool people", .method = []() { Settings::setCurrentCategory(6); }, .isTogglable = false, .toolTip = "Opens the cool people page"},
            },
            {//Settings - 1
                    ButtonInfo {.buttonText = "Back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "Right hand menu", .enableMethod = []() { Settings::rightHanded = true; }, .disableMethod = []() { Settings::rightHanded = false; }, .toolTip = "Sets the menu to right hand"},
                    ButtonInfo {.buttonText = "Notifications", .enableMethod = []() { NotiLib::SetEnabled(true); }, .disableMethod = []() { NotiLib::SetEnabled(false); }, .enabled = true, .toolTip = "Toggles the notifications"},
                    ButtonInfo {.buttonText = "Disconnect button", .enableMethod = []() { Settings::disconnectButton = true; }, .disableMethod = []() { Settings::disconnectButton = false; }, .enabled = true, .toolTip = "Toggles the disconnect button"},
            },
            {//Movement - 2
                    ButtonInfo {.buttonText = "Back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "Platforms", .method = []() { Movement::platforms(); }, .toolTip = "Platforms"},
                    ButtonInfo {.buttonText = "Hand Fly", .method = []() { Movement::HandFly(); }, .toolTip = "Hand Fly"},
                    ButtonInfo {.buttonText = "Long Arms", .method = []() { Movement::Longarms(true); }, .toolTip = "Long Arm"},
                    ButtonInfo {.buttonText = "Car", .method = []() { Movement::Car(); }, .toolTip = "Car"},
                    ButtonInfo {.buttonText = "Slingshot Fly", .method = []() { Movement::SlingshotFly(); }, .toolTip = "Slingshot Fly"},
                    },
            {//Player - 3
                    ButtonInfo {.buttonText = "Back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "TempName1", .method = []() { PlayerMods::TempName1(); }, .toolTip = "Temp"},
                    ButtonInfo {.buttonText = "TempName2", .method = []() { PlayerMods::TempName2(); }, .toolTip = "Temp"},
                    ButtonInfo {.buttonText = "TempName3", .method = []() { PlayerMods::TempName3(); }, .toolTip = "Temp"},
                    ButtonInfo {.buttonText = "TempName4", .method = []() { PlayerMods::TempName4(); }, .toolTip = "Temp"},
            },
            {//Overpowered - 4
                    ButtonInfo {.buttonText = "back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "Crash All (RT)", .method = []() { OverpoweredMods::CrashAll(); }, .toolTip = "Crash All"},
                    ButtonInfo {.buttonText = "Always Master", .method = []() { OverpoweredMods::SetMaster(); }, .toolTip = "Set Master"},
                    },
            {//Credits - 5
                    ButtonInfo {.buttonText = "back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "Glitch", .isTogglable = false, .toolTip = "Ported the menu from iiDk's template and the dev of this menu"},
                    ButtonInfo {.buttonText = "Ossuary", .isTogglable = false, .toolTip = "Taught me how to mod :D"},
                    ButtonInfo {.buttonText = "Pubert", .isTogglable = false, .toolTip = "Helped me a lot with the code"},
                    ButtonInfo {.buttonText = "Notfishvr", .isTogglable = false, .toolTip = "Helped me a lot debugging"},
            },
            {//Cool people - 6
                    ButtonInfo {.buttonText = "back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "TempName", .isTogglable = false, .toolTip = "Cool person :D"},
                    ButtonInfo {.buttonText = "TempName", .isTogglable = false, .toolTip = "Cool person :D"},
                    ButtonInfo {.buttonText = "TempName", .isTogglable = false, .toolTip = "Cool person :D"},
                    ButtonInfo {.buttonText = "TempName", .isTogglable = false, .toolTip = "Cool person :D"},
                    ButtonInfo {.buttonText = "TempName", .isTogglable = false, .toolTip = "Cool person :D"},
            },
            {//Bots - 7  (multi-client Photon bots — real room joins)
                    ButtonInfo {.buttonText = "Back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Back"},
                    ButtonInfo {.buttonText = "Spawn Bots", .method = []() { BotMods::SpawnBots(); }, .isTogglable = false, .toolTip = "Multi-client join + event 202 rig"},
                    ButtonInfo {.buttonText = "Stop Bots", .method = []() { BotMods::StopBots(); }, .isTogglable = false, .toolTip = "Disconnect all bot clients"},
                    ButtonInfo {.buttonText = "Remove Some", .method = []() { BotMods::RemoveSome(); }, .isTogglable = false, .toolTip = "Drop last N bots"},
                    ButtonInfo {.buttonText = "Cycle Mode", .method = []() { BotMods::CycleMode(); }, .isTogglable = false, .toolTip = "Stop/Orbit/Stack/Line/Spaz"},
                    ButtonInfo {.buttonText = "Orbit Me", .method = []() { BotMods::SetMode(1); }, .isTogglable = false, .toolTip = "Orbit local player"},
                    ButtonInfo {.buttonText = "Stack", .method = []() { BotMods::SetMode(3); }, .isTogglable = false, .toolTip = "Stack vertically"},
                    ButtonInfo {.buttonText = "Line", .method = []() { BotMods::SetMode(4); }, .isTogglable = false, .toolTip = "Line formation"},
                    ButtonInfo {.buttonText = "Spaz", .method = []() { BotMods::SetMode(5); }, .isTogglable = false, .toolTip = "Spaz movement"},
                    ButtonInfo {.buttonText = "Freeze", .enableMethod = []() { BotMods::freezeBots = true; }, .disableMethod = []() { BotMods::freezeBots = false; }, .toolTip = "Freeze rig updates"},
                    ButtonInfo {.buttonText = "Count +", .method = []() { BotMods::IncCount(); }, .isTogglable = false, .toolTip = "Increase bot count"},
                    ButtonInfo {.buttonText = "Count -", .method = []() { BotMods::DecCount(); }, .isTogglable = false, .toolTip = "Decrease bot count"},
                    ButtonInfo {.buttonText = "Radius +", .method = []() { BotMods::IncRadius(); }, .isTogglable = false, .toolTip = "Orbit radius up"},
                    ButtonInfo {.buttonText = "Radius -", .method = []() { BotMods::DecRadius(); }, .isTogglable = false, .toolTip = "Orbit radius down"},
            },
    };
};