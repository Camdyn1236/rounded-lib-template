#pragma once
#include "../BNMResolve.hpp"
#include "../BNMIncludes.hpp"
#include "../PhotonResolve.hpp"
#include "../NotiLib/NotiLib.hpp"
#include <vector>
#include <string>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <cstdio>

using namespace BNM;
using namespace BNM::Structures;
using namespace BNM::Structures::Unity;

/*
 * Multi-client Photon bots (JupiterX-style) — compile-safe BNM port.
 * Each bot = LoadBalancingClient → lobby → same room → event 202 / 206.
 */

class BotMods {
public:
    static inline int botCount = 5;
    static inline float botRadius = 3.5f;
    static inline float botHeight = 0.3f;
    static inline float botSpeed = 60.f;
    static inline int movementMode = 1;
    static inline bool botsActive = false;
    static inline bool freezeBots = false;
    static inline bool rainbow = false;
    static inline bool spinEffect = false;
    static inline bool bobUpDown = false;
    static inline bool spawning = false;
    static inline float spawnDelayAccum = 0.f;
    static inline std::string botPrefix = "BOT";
    static inline std::string roomName;
    static inline Vector3 spawnCenter = Vector3(0.f, 1.f, 0.f);

    static const uint8_t PUN_INSTANTIATE_EVENT = 202;
    static const uint8_t PUN_SERIALIZATION_EVENT = 206;
    static const int MAX_VIEW_IDS = 1000;

    static inline const char* kPrefabs[] = {
        "GorillaPrefabs/Gorilla Player Networked",
        "GorillaPrefabs/Gorilla Player Actual",
        "gorillaprefabs/Gorilla Player Networked",
        nullptr
    };

    struct BotConnection {
        std::string name;
        Vector3 targetPos{};
        Vector3 spawnPos{};
        int botIndex = 0;
        IL2CPP::Il2CppObject* client = nullptr;
        bool inRoom = false;
        bool rigSent = false;
        bool lobbySent = false;
        bool joinSent = false;
        int rigViewId = -1;
        int lastRigSendMs = 0;
        float lobbyRetry = 0.f;
        float joinRetry = 0.f;
        bool alive = false;

        void Cleanup() {
            try {
                if (client) {
                    Class lbc = Class("Photon.Realtime", "LoadBalancingClient");
                    Method<void> d0 = lbc.GetMethod("Disconnect", 0);
                    if (d0.IsValid()) d0[client]();
                    else {
                        Method<void> d1 = lbc.GetMethod("Disconnect", 1);
                        if (d1.IsValid()) d1[client](0);
                    }
                }
            } catch (...) {}
            client = nullptr;
            inRoom = false;
            rigSent = false;
            alive = false;
        }

        bool EnsureClient(AppSettings* settings) {
            try {
                Class lbcCls = Class("Photon.Realtime", "LoadBalancingClient");
                if (!lbcCls.IsValid()) return false;

                IL2CPP::Il2CppObject* obj = lbcCls.CreateNewObjectParameters();
                if (!obj) return false;
                client = obj;

                try {
                    Method<void> setNick = lbcCls.GetMethod("set_NickName", 1);
                    if (setNick.IsValid()) setNick[client](CreateMonoString(name));
                } catch (...) {}

                try {
                    Class authCls = Class("Photon.Realtime", "AuthenticationValues");
                    IL2CPP::Il2CppObject* auth = authCls.CreateNewObjectParameters();
                    if (auth) {
                        char uid[64];
                        std::snprintf(uid, sizeof(uid), "bot-%d-%d", botIndex, (int)(Time::GetTime() * 1000.f) + (rand() & 0xffff));
                        Method<void> setUid = authCls.GetMethod("set_UserId", 1);
                        if (setUid.IsValid()) setUid[auth](CreateMonoString(uid));
                        Method<void> setAuth = lbcCls.GetMethod("set_AuthValues", 1);
                        if (setAuth.IsValid()) setAuth[client](auth);
                    }
                } catch (...) {}

                try {
                    if (settings) {
                        Method<bool> connect = lbcCls.GetMethod("ConnectUsingSettings", 1);
                        if (connect.IsValid()) {
                            connect[client](settings);
                            alive = true;
                            return true;
                        }
                    }
                    Method<bool> connect0 = lbcCls.GetMethod("ConnectUsingSettings", 0);
                    if (connect0.IsValid()) {
                        connect0[client]();
                        alive = true;
                        return true;
                    }
                } catch (...) {}
                return false;
            } catch (...) {
                client = nullptr;
                return false;
            }
        }

        void Service() {
            if (!client) return;
            try {
                Class lbc = Class("Photon.Realtime", "LoadBalancingClient");
                Method<void> svc = lbc.GetMethod("Service", 0);
                if (svc.IsValid()) svc[client]();
            } catch (...) {}
        }

        bool GetInRoom() {
            try {
                Method<bool> m = Class("Photon.Realtime", "LoadBalancingClient").GetMethod("get_InRoom", 0);
                if (m.IsValid()) return m[client]();
            } catch (...) {}
            return false;
        }

        bool GetInLobby() {
            try {
                Method<bool> m = Class("Photon.Realtime", "LoadBalancingClient").GetMethod("get_InLobby", 0);
                if (m.IsValid()) return m[client]();
            } catch (...) {}
            return false;
        }

        bool GetIsConnectedAndReady() {
            try {
                Method<bool> m = Class("Photon.Realtime", "LoadBalancingClient").GetMethod("get_IsConnectedAndReady", 0);
                if (m.IsValid()) return m[client]();
            } catch (...) {}
            return false;
        }

        int GetLocalActor() {
            try {
                Class lbc = Class("Photon.Realtime", "LoadBalancingClient");
                Method<IL2CPP::Il2CppObject*> getLP = lbc.GetMethod("get_LocalPlayer", 0);
                if (!getLP.IsValid()) return -1;
                IL2CPP::Il2CppObject* lp = getLP[client]();
                if (!lp) return -1;
                Method<int> getActor = Class("Photon.Realtime", "Player").GetMethod("get_ActorNumber", 0);
                if (getActor.IsValid()) return getActor[lp]();
            } catch (...) {}
            return -1;
        }

        bool OpJoinLobby() {
            try {
                Class lbc = Class("Photon.Realtime", "LoadBalancingClient");
                Method<bool> m1 = lbc.GetMethod("OpJoinLobby", 1);
                if (m1.IsValid()) {
                    Field<IL2CPP::Il2CppObject*> def = Class("Photon.Realtime", "TypedLobby").GetField("Default");
                    IL2CPP::Il2CppObject* lobby = nullptr;
                    if (def.IsValid()) lobby = def.Get();
                    if (lobby) return m1[client](lobby);
                }
                Method<bool> m0 = lbc.GetMethod("OpJoinLobby", 0);
                if (m0.IsValid()) return m0[client]();
            } catch (...) {}
            return false;
        }

        bool OpJoinRoom(const std::string& room) {
            try {
                Class lbc = Class("Photon.Realtime", "LoadBalancingClient");
                Class erpCls = Class("Photon.Realtime", "EnterRoomParams");
                IL2CPP::Il2CppObject* erp = erpCls.CreateNewObjectParameters();
                if (!erp) return false;
                Field<String*> rn = erpCls.GetField("RoomName");
                if (rn.IsValid()) {
                    rn.SetInstance(erp);
                    rn.Set(CreateMonoString(room));
                }
                Method<bool> m = lbc.GetMethod("OpJoinRoom", 1);
                if (m.IsValid()) return m[client](erp);
            } catch (...) {}
            return false;
        }

        // Avoid SendOptions value-type invoke issues: use PhotonNetwork.RaiseEvent only as last resort.
        // For bot client, call OpRaiseEvent with 2 args if available, else skip payload safely.
        bool OpRaiseEventSimple(uint8_t code, IL2CPP::Il2CppObject* content) {
            if (!client) return false;
            try {
                Class lbc = Class("Photon.Realtime", "LoadBalancingClient");
                // Try OpRaiseEvent(byte, object, RaiseEventOptions, SendOptions) — skip if signature hard
                Method<bool> mb = lbc.GetMethod("OpRaiseEvent", 2);
                if (!mb.IsValid()) { /* try other */ }

                RaiseEventOptions* opts = RaiseEventOptions::GetDefault();
                if (!opts) {
                    opts = (RaiseEventOptions*)Class("Photon.Realtime", "RaiseEventOptions").CreateNewObjectParameters();
                }
                if (opts) {
                    try {
                        Class roc = Class("Photon.Realtime", "RaiseEventOptions");
                        Field<int> receivers = roc.GetField("Receivers");
                        if (receivers.IsValid()) {
                            receivers.SetInstance((IL2CPP::Il2CppObject*)opts);
                            receivers.Set(1); // Others
                        }
                        Field<int> caching = roc.GetField("CachingOption");
                        if (caching.IsValid()) {
                            caching.SetInstance((IL2CPP::Il2CppObject*)opts);
                            caching.Set(4); // AddToRoomCache-ish
                        }
                    } catch (...) {}
                }

                // Prefer 2-parameter overload if any
                Method<bool> m2 = lbc.GetMethod("OpRaiseEvent", 2);
                if (m2.IsValid()) {
                    return m2[client](code, content);
                }

                // 4-arg: pass SendOptions via temporary on stack — may not marshal; guarded
                Method<bool> m4 = lbc.GetMethod("OpRaiseEvent", 4);
                if (m4.IsValid() && opts) {
                    SendOptions send = SendOptions::sendReliable();
                    try {
                        return m4[client](code, content, (IL2CPP::Il2CppObject*)opts, send);
                    } catch (...) {
                        return false;
                    }
                }
            } catch (...) {}
            return false;
        }

        IL2CPP::Il2CppObject* NewHashtable() {
            try {
                Class htCls = Class("ExitGames.Client.Photon", "Hashtable");
                if (!htCls.IsValid()) return nullptr;
                return htCls.CreateNewObjectParameters();
            } catch (...) {
                return nullptr;
            }
        }

        void HashtableAddString(IL2CPP::Il2CppObject* ht, const std::string& key, const std::string& val) {
            if (!ht) return;
            try {
                Class htCls = Class("ExitGames.Client.Photon", "Hashtable");
                Method<void> add = htCls.GetMethod("Add", 2);
                if (add.IsValid()) add[ht](CreateMonoString(key), CreateMonoString(val));
            } catch (...) {}
        }

        void CreateRig() {
            if (rigSent || !client) return;
            try {
                int actor = GetLocalActor();
                if (actor <= 0) return;
                int baseView = actor * MAX_VIEW_IDS;
                rigViewId = baseView + 1;

                for (int i = 0; kPrefabs[i] != nullptr; i++) {
                    try {
                        IL2CPP::Il2CppObject* ht = NewHashtable();
                        if (!ht) continue;
                        HashtableAddString(ht, "0", kPrefabs[i]);
                        HashtableAddString(ht, "prefab", kPrefabs[i]);
                        HashtableAddString(ht, "view", std::to_string(rigViewId));
                        OpRaiseEventSimple(PUN_INSTANTIATE_EVENT, ht);
                    } catch (...) {}
                }
                rigSent = true;
            } catch (...) {}
        }

        void UpdateRig() {
            if (!client || !inRoom || rigViewId < 0 || BotMods::freezeBots) return;
            int now = (int)(Time::GetTime() * 1000.f);
            if (now - lastRigSendMs < 100) return;
            lastRigSendMs = now;
            try {
                IL2CPP::Il2CppObject* ht = NewHashtable();
                if (!ht) return;
                HashtableAddString(ht, "vid", std::to_string(rigViewId));
                HashtableAddString(ht, "px", std::to_string(targetPos.x));
                HashtableAddString(ht, "py", std::to_string(targetPos.y));
                HashtableAddString(ht, "pz", std::to_string(targetPos.z));
                OpRaiseEventSimple(PUN_SERIALIZATION_EVENT, ht);
            } catch (...) {}
        }

        void Tick(float time) {
            if (!client || !alive) return;
            try {
                if (!inRoom) {
                    if (GetInRoom()) {
                        inRoom = true;
                        joinSent = false;
                        CreateRig();
                        return;
                    }
                    if (GetInLobby()) {
                        if (!joinSent || time > joinRetry) {
                            if (OpJoinRoom(BotMods::roomName)) {
                                joinSent = true;
                                joinRetry = time + 3.f;
                            } else {
                                joinRetry = time + 3.f;
                            }
                        }
                        return;
                    }
                    if (GetIsConnectedAndReady()) {
                        if (!lobbySent || time > lobbyRetry) {
                            if (OpJoinLobby()) {
                                lobbySent = true;
                                lobbyRetry = time + 3.f;
                            } else {
                                lobbyRetry = time + 3.f;
                            }
                        }
                    } else {
                        lobbySent = false;
                        joinSent = false;
                    }
                    return;
                }
                if (!GetInRoom()) {
                    inRoom = false;
                    rigSent = false;
                    joinSent = false;
                    return;
                }
                UpdateRig();
            } catch (...) {}
        }
    };

    static inline std::vector<BotConnection> bots;

    static const char* ModeName(int m) {
        switch (m) {
            case 0: return "Stop";
            case 1: return "Orbit";
            case 3: return "Stack";
            case 4: return "Line";
            case 5: return "Spaz";
            default: return "Orbit";
        }
    }

    static void Notify(const std::string& s) {
        try { BNM_LOG_INFO("[Bots] %s", s.c_str()); } catch (...) {}
        try {
#if __has_include("../NotiLib/NotiLib.hpp")
            NotiLib::SendNotification(std::string("<color=cyan>[Bots]</color> ") + s);
#endif
        } catch (...) {}
    }

    static bool InPhotonRoom() {
        try { return PhotonNetwork::GetInRoom() && PhotonNetwork::GetCurrentRoom() != nullptr; }
        catch (...) { return false; }
    }

    static Vector3 GetLocalPos() {
        try {
            Class playerCls = Class("GorillaLocomotion", "Player");
            if (!playerCls.IsValid()) return Vector3(0.f, 1.f, 0.f);
            Field<IL2CPP::Il2CppObject*> instF = playerCls.GetField("Instance");
            IL2CPP::Il2CppObject* inst = instF();
            if (!inst) return Vector3(0.f, 1.f, 0.f);
            Transform* t = ((Component*)inst)->GetTransform();
            if (t) return t->GetPosition();
        } catch (...) {}
        return Vector3(-64.f, 12.5f, -83.f);
    }

    static std::string GetCurrentRoomName() {
        try {
            Room* room = PhotonNetwork::GetCurrentRoom();
            if (!room) return "";
            Method<String*> getName = Class("Photon.Realtime", "Room").GetMethod("get_Name", 0);
            if (getName.IsValid()) {
                String* s = getName[(IL2CPP::Il2CppObject*)room]();
                if (s) return s->str();
            }
        } catch (...) {}
        return "";
    }

    static AppSettings* CloneAppSettings() {
        try {
            ServerSettings* ss = PhotonNetwork::GetPhotonServerSettings();
            if (!ss) return nullptr;
            AppSettings* src = ss->GetAppSettings();
            if (!src) return nullptr;
            Class asCls = Class("Photon.Realtime", "AppSettings");
            AppSettings* cfg = (AppSettings*)asCls.CreateNewObjectParameters();
            if (!cfg) return src;
            try {
                cfg->SetAppIdRealtime(src->GetAppIdRealtime());
                cfg->SetAppVersion(src->GetAppVersion());
                cfg->SetUseNameServer(true);
                Field<String*> fr = asCls.GetField("FixedRegion");
                if (fr.IsValid()) {
                    fr.SetInstance((IL2CPP::Il2CppObject*)src);
                    String* region = fr.Get();
                    if (region) {
                        fr.SetInstance((IL2CPP::Il2CppObject*)cfg);
                        fr.Set(region);
                    }
                }
            } catch (...) {}
            return cfg;
        } catch (...) {
            return nullptr;
        }
    }

    static void StopBots() {
        spawning = false;
        for (auto& b : bots) {
            try { b.Cleanup(); } catch (...) {}
        }
        bots.clear();
        botsActive = false;
        Notify("Stopped / cleared bots");
    }

    static void SpawnBots() {
        try {
            if (!InPhotonRoom()) {
                Notify("Join a room first");
                return;
            }
            if (spawning || !bots.empty()) {
                Notify("Stopping existing bots first");
                StopBots();
            }
            roomName = GetCurrentRoomName();
            if (roomName.empty()) {
                Notify("Room name empty");
                return;
            }
            spawnCenter = GetLocalPos();
            spawning = true;
            spawnDelayAccum = 0.f;
            botsActive = true;
            Notify(std::string("Spawning ") + std::to_string(botCount) + " multi-client bots in [" + roomName + "]");
        } catch (...) {
            Notify("Spawn failed safe");
            spawning = false;
        }
    }

    static void PumpSpawn(float dt) {
        if (!spawning) return;
        if (!InPhotonRoom()) {
            spawning = false;
            return;
        }
        int target = std::max(1, std::min(botCount, 20));
        if ((int)bots.size() >= target) {
            spawning = false;
            Notify(std::string("All bots started: ") + std::to_string(bots.size()));
            return;
        }
        spawnDelayAccum += dt;
        if (spawnDelayAccum < 0.5f) return;
        spawnDelayAccum = 0.f;

        try {
            int i = (int)bots.size();
            float angle = i * 2.399963f;
            Vector3 pos(
                spawnCenter.x + cosf(angle) * 1.5f,
                spawnCenter.y + botHeight,
                spawnCenter.z + sinf(angle) * 1.5f
            );

            BotConnection bot;
            char num[8];
            std::snprintf(num, sizeof(num), "%02d", i + 1);
            bot.name = botPrefix + num;
            bot.spawnPos = pos;
            bot.targetPos = pos;
            bot.botIndex = i;
            bot.alive = false;

            AppSettings* cfg = CloneAppSettings();
            if (!bot.EnsureClient(cfg)) {
                Notify(std::string("Failed client: ") + bot.name);
                return;
            }
            bots.push_back(std::move(bot));
            Notify(std::string("Connecting ") + bots.back().name);
        } catch (...) {
            Notify("Spawn step exception");
        }
    }

    static void UpdateMovement(float dt) {
        if (bots.empty() || freezeBots) return;
        Vector3 center = GetLocalPos();
        float t = Time::GetTime();
        int total = (int)bots.size();
        if (total <= 0) return;

        switch (movementMode) {
            case 1: {
                static float orbitAngle = 0.f;
                orbitAngle += botSpeed * dt;
                if (orbitAngle >= 360.f) orbitAngle -= 360.f;
                for (int i = 0; i < total; i++) {
                    float deg = orbitAngle + (360.f / total) * i;
                    float rad = deg * 0.0174532924f;
                    bots[i].targetPos = Vector3(
                        center.x + cosf(rad) * botRadius,
                        center.y + botHeight,
                        center.z + sinf(rad) * botRadius
                    );
                }
                break;
            }
            case 3:
                for (int i = 0; i < total; i++)
                    bots[i].targetPos = Vector3(center.x, center.y + 1.f + i * 1.2f, center.z);
                break;
            case 4:
                for (int i = 0; i < total; i++)
                    bots[i].targetPos = Vector3(center.x + (i - (total - 1) / 2.f) * 2.f, center.y + botHeight, center.z);
                break;
            case 5:
                for (int i = 0; i < total; i++) {
                    bots[i].targetPos = Vector3(
                        center.x + sinf(t * 8.f + i) * 3.f,
                        center.y + 0.3f + fabsf(cosf(t * 5.f + i)) * 3.f,
                        center.z + cosf(t * 7.f + i) * 3.f
                    );
                }
                break;
            default:
                break;
        }
    }

    static void Tick(float dt) {
        try {
            PumpSpawn(dt);
            float time = Time::GetTime();
            for (auto& b : bots) {
                try {
                    b.Service();
                    b.Tick(time);
                } catch (...) {}
            }
            UpdateMovement(dt);
        } catch (...) {}
    }

    static void ClearBots() { StopBots(); }
    static void RemoveSome() {
        int n = std::min(botCount, (int)bots.size());
        for (int i = 0; i < n && !bots.empty(); i++) {
            bots.back().Cleanup();
            bots.pop_back();
        }
        if (bots.empty()) botsActive = false;
        Notify(std::string("Left=") + std::to_string(bots.size()));
    }

    static void CycleMode() {
        static int modes[] = {0, 1, 3, 4, 5};
        int idx = 0;
        for (int i = 0; i < 5; i++) if (modes[i] == movementMode) { idx = i; break; }
        movementMode = modes[(idx + 1) % 5];
        Notify(std::string("Mode: ") + ModeName(movementMode));
    }
    static void SetMode(int m) { movementMode = m; Notify(std::string("Mode: ") + ModeName(m)); }
    static void IncCount() { botCount = std::min(botCount + 1, 20); Notify(std::string("Count=") + std::to_string(botCount)); }
    static void DecCount() { botCount = std::max(botCount - 1, 1); Notify(std::string("Count=") + std::to_string(botCount)); }
    static void IncRadius() { botRadius = std::min(botRadius + 0.5f, 15.f); Notify(std::string("Radius=") + std::to_string(botRadius)); }
    static void DecRadius() { botRadius = std::max(botRadius - 0.5f, 1.f); Notify(std::string("Radius=") + std::to_string(botRadius)); }
    static void EnableNetworkSpawn() { Notify("Multi-client mode active"); }
    static void DisableNetworkSpawn() { Notify("Use Stop Bots"); }
};
