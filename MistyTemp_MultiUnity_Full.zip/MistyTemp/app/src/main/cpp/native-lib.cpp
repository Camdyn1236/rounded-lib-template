// lang: C++, file: native-lib.cpp
// target: Quest / Meta Horizon, multi Unity IL2CPP (BNM resolves at runtime)
// *original MistyTemp surface: menu + bots + playfab + MOTD*
// *every hook validated; missing symbols = skip, never abort*

#include <jni.h>
#include <string>
#include <random>
#include <vector>

#include "BNM/Loading.hpp"
#include "BNM/UnityStructures.hpp"
#include "BNM/Method.hpp"
#include "BNM/MethodBase.hpp"
#include "BNM/Class.hpp"
#include "BNM/Field.hpp"
#include "BNM/Image.hpp"
#include "BNM/Utils.hpp"
#include "BNMResolve.hpp"
#include "BNM/Il2CppHeaders.hpp"
#include <BNMIncludes.hpp>
#include "Include/Menu/ModMenu.hpp"
#include "Include/NotiLib/NotiLib.hpp"
#include "Include/PhotonResolve.hpp"
#include "Include/Mods/Bots.hpp"

using namespace BNM;
using namespace BNM::Structures;
using namespace BNM::Structures::Unity;
using namespace BNM::Structures::Mono;
using namespace BNM::IL2CPP;

// ---------------------------------------------------------------------------
// version-agnostic resolvers
// ---------------------------------------------------------------------------
static Image ResolveImage(std::initializer_list<const char*> names) {
    for (auto n : names) {
        try {
            Image img(n);
            if (img.IsValid()) return img;
        } catch (...) {}
    }
    // bare search: empty image still allows Class(ns, name) global walk
    return Image();
}

static Class ResolveClass(const char* ns, const char* name,
                          std::initializer_list<const char*> images = {}) {
    try {
        if (images.size()) {
            Image img = ResolveImage(images);
            if (img.IsValid()) {
                Class c(ns, name, img);
                if (c.IsValid()) return c;
            }
        }
        Class c(ns, name);
        if (c.IsValid()) return c;
    } catch (...) {}
    return Class();
}

static MethodBase ResolveMethod(Class& cls, std::initializer_list<const char*> names, int argc = -1) {
    if (!cls.IsValid()) return MethodBase();
    for (auto n : names) {
        try {
            MethodBase m = (argc >= 0) ? cls.GetMethod(n, argc) : cls.GetMethod(n);
            if (m.IsValid()) return m;
            // try alternate argc
            if (argc >= 0) {
                MethodBase m2 = cls.GetMethod(n);
                if (m2.IsValid()) return m2;
            }
        } catch (...) {}
    }
    return MethodBase();
}

template<typename NEW_T, typename OLD_T>
static bool SafeInvokeHook(MethodBase meth, NEW_T neu, OLD_T& old) {
    if (!meth.IsValid()) return false;
    try {
        return InvokeHook(meth, neu, old);
    } catch (...) {
        return false;
    }
}

template<typename NEW_T, typename OLD_T>
static bool SafeBasicHook(MethodBase meth, NEW_T neu, OLD_T& old) {
    if (!meth.IsValid()) return false;
    try {
        BasicHook(meth, neu, old);
        return true;
    } catch (...) {
        return false;
    }
}

// ---------------------------------------------------------------------------
// helpers / state
// ---------------------------------------------------------------------------
static AppSettings* photonServerSettings = nullptr;
static GameObject* motdtext = nullptr;
static Text* txtlol = nullptr;
static Player* localPlayer = nullptr;
static std::string cachedTitleId = "NULL";
static std::string cachedPlayerId = "NULL";
static std::string cachedNickname = "NULL";
static std::string cachedRealtimeId = "NULL";
static std::string cachedVoiceId = "NULL";
static std::string cachedAppVersion = "NULL";
static bool bol = false;

static std::string gen(int length) {
    static const char* characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    static std::mt19937 generator{std::random_device{}()};
    std::uniform_int_distribution<> distribution(0, 61);
    std::string randomString;
    randomString.reserve(length);
    for (int i = 0; i < length; ++i)
        randomString += characters[distribution(generator)];
    return randomString;
}

// ---------------------------------------------------------------------------
// PlayFab
// ---------------------------------------------------------------------------
void* (*old_LoginWithCustomID)(Il2CppObject*, Il2CppObject*, Il2CppObject*, Il2CppObject*, Il2CppObject*) = nullptr;

void* new_LoginWithCustomID(Il2CppObject* request, Il2CppObject* resultCallback,
                            Il2CppObject* errorCallback, Il2CppObject* customData,
                            Il2CppObject* extraHeaders) {
    try {
        Class reqCls = ResolveClass("PlayFab.ClientModels", "LoginWithCustomIDRequest");
        if (reqCls.IsValid() && request) {
            Field<String*> CustomId = reqCls.GetField("CustomId");
            if (CustomId.IsValid()) {
                CustomId.SetInstance(request);
                String* customId = CustomId();
                if (customId) {
                    std::string str = customId->str();
                    if (str.rfind("OCULUS", 0) != 0)
                        CustomId.Set(CreateMonoString(gen(16)));
                }
            }
        }
    } catch (...) {}
    if (old_LoginWithCustomID)
        return old_LoginWithCustomID(request, resultCallback, errorCallback, customData, extraHeaders);
    return nullptr;
}

// ---------------------------------------------------------------------------
// Player lifecycle hooks
// ---------------------------------------------------------------------------
void (*old_Awake)(void*) = nullptr;
void new_Awake(void* instance) {
    if (old_Awake) {
        try { old_Awake(instance); } catch (...) {}
    }
    try { ModMenu::Init(); } catch (...) {
        BNM_LOG_INFO("ModMenu::Init skipped/failed (safe)");
    }
}

void (*old_LateUpdate)(void*) = nullptr;
void new_LateUpdate(void* instance) {
    if (old_LateUpdate) {
        try { old_LateUpdate(instance); } catch (...) {}
    }
    try { ModMenu::Update(); } catch (...) {}
    try { BotMods::Tick(0.02f); } catch (...) {}
}

void (*old_FixedUpdate)(void*) = nullptr;
void new_FixedUpdate(void* instance) {
    if (old_FixedUpdate) {
        try { old_FixedUpdate(instance); } catch (...) {}
    }

    try {
        if (!bol) {
            try {
                motdtext = GameObject::Find("motdtext");
                if (motdtext) {
                    auto* comp = motdtext->GetComponent(Text::GetType());
                    if (comp) txtlol = (Text*)comp;
                }
            } catch (...) {}

            try {
                auto* ss = PhotonNetwork::GetPhotonServerSettings();
                if (ss) {
                    photonServerSettings = ss->GetAppSettings();
                    if (photonServerSettings) {
                        try { cachedRealtimeId = photonServerSettings->GetAppIdRealtime(); } catch (...) {}
                        try { cachedVoiceId = photonServerSettings->GetAppIdVoice(); } catch (...) {}
                        try { cachedAppVersion = photonServerSettings->GetAppVersion(); } catch (...) {}
                    }
                }
            } catch (...) {}
            bol = true;
        }

        if (txtlol) {
            try {
                localPlayer = PhotonNetwork::GetLocalPlayer();
                if (localPlayer) {
                    try { cachedPlayerId = localPlayer->GetUserId(); } catch (...) { cachedPlayerId = "?"; }
                    try { cachedNickname = localPlayer->GetNickname(); } catch (...) { cachedNickname = "?"; }
                } else {
                    cachedPlayerId = "Not in room";
                    cachedNickname = "Not in room";
                }
                std::string output =
                    "NAME ON TOP\n\n"
                    "Realtime: " + cachedRealtimeId + "\n"
                    "Voice: " + cachedVoiceId + "\n"
                    "Version: " + cachedAppVersion + "\n"
                    "Title ID: " + cachedTitleId + "\n"
                    "Player ID: " + cachedPlayerId + "\n"
                    "Nickname: " + cachedNickname;
                txtlol->SetText(output);
            } catch (...) {}

            try {
                if (motdtext) {
                    auto* renderer = (Renderer*)motdtext->GetComponent(Renderer::GetType());
                    if (renderer) {
                        Material* material = renderer->GetMaterial();
                        if (material)
                            material->SetColor(Color(1.0f, 0.0f, 0.0f, 0.8f));
                    }
                }
            } catch (...) {}
        }
    } catch (...) {}
}

// ---------------------------------------------------------------------------
// OnLoaded — multi-version hook install
// ---------------------------------------------------------------------------
void OnLoaded() {
    BNM_LOG_INFO(BNM_OBFUSCATE("misty multi-unity hook arm"));

    // GorillaLocomotion.Player across common assembly names / stripped names
    Class player = ResolveClass(
        "GorillaLocomotion", "Player",
        {"Assembly-CSharp.dll", "Assembly-CSharp", "GorillaLocomotion.dll"}
    );
    if (!player.IsValid()) {
        // last resort: no image filter
        player = ResolveClass("GorillaLocomotion", "Player");
    }

    int hooked = 0;
    if (player.IsValid()) {
        MethodBase late = ResolveMethod(player, {"LateUpdate"}, 0);
        if (SafeInvokeHook(late, new_LateUpdate, old_LateUpdate)) {
            BNM_LOG_INFO("LateUpdate hooked");
            hooked++;
        }
        MethodBase awake = ResolveMethod(player, {"Awake"}, 0);
        if (SafeInvokeHook(awake, new_Awake, old_Awake)) {
            BNM_LOG_INFO("Awake hooked");
            hooked++;
        }
        MethodBase fixedU = ResolveMethod(player, {"FixedUpdate"}, 0);
        if (SafeInvokeHook(fixedU, new_FixedUpdate, old_FixedUpdate)) {
            BNM_LOG_INFO("FixedUpdate hooked");
            hooked++;
        }
    } else {
        BNM_LOG_INFO("GorillaLocomotion.Player not found — menu/bots idle until present");
    }

    // PlayFab — several possible assemblies
    Class playfab = ResolveClass("PlayFab", "PlayFabClientAPI",
                                 {"PlayFab.dll", "Assembly-CSharp.dll", "PlayFabClientAPI.dll"});
    if (!playfab.IsValid())
        playfab = ResolveClass("PlayFab", "PlayFabClientAPI");
    if (playfab.IsValid()) {
        MethodBase login = ResolveMethod(playfab, {"LoginWithCustomID"}, 5);
        if (!login.IsValid())
            login = ResolveMethod(playfab, {"LoginWithCustomID"}, -1);
        if (SafeBasicHook(login, new_LoginWithCustomID, old_LoginWithCustomID)) {
            BNM_LOG_INFO("PlayFab LoginWithCustomID hooked");
            hooked++;
        }
    }

    BNM_LOG_INFO(BNM_OBFUSCATE("hook install done, count=%d"), hooked);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, [[maybe_unused]] void* reserved) {
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK)
        return JNI_ERR;

    try {
        BNM::Loading::AddOnLoadedEvent(OnLoaded);
    } catch (...) {}

    try {
        if (!BNM::Loading::TryLoadByJNI(env)) {
            BNM_LOG_INFO("TryLoadByJNI returned false — still exporting JNI_VERSION");
        }
    } catch (...) {}

    // never return JNI_ERR after partial init — keep process alive
    return JNI_VERSION_1_6;
}

// crash-log stubs used by optional soundboard bits
extern "C" void EnvySetCrashLogPath(const char* path) {
    BNM_LOG_INFO("Crash log path: %s", path ? path : "null");
}
extern "C" void EnvySetCrashContext(const char* context) {
    if (context) BNM_LOG_INFO("Crash context: %s", context);
}
