// stripped — no menu / bots modules
#pragma once
